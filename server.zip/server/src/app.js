const express = require("express");
const bodyParser = require('body-parser');
const app = express()
const cors = require('cors')
const conferenceData = require('./conferenceData')


app.use(cors());
app.use(bodyParser.urlencoded({extended: true}))
app.use(express.static('resources'))

app.get('/', function(req,res) {
  try{
    res.send('NFL Conference Data')
  } catch (error) {
    res.status(500).send(error)
  }
})

app.get('/nflTeams', function(req,res) {
  try {
    res.send(conferenceData)
  }catch (error){
    res.status(500).send(error)
  }
})

app.listen(8000, () => {
  console.log('http://localhost:8000/')
})