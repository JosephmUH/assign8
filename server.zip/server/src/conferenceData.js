let afcConference = [
    {​​division:'AFC East', teamName: 'Buffalo Bills', wins: 6, losses:2, ties:0},
    {​​division:'AFC East', teamName: ' Miami Dolphins', wins: 4, losses:3, ties:0},
    {​​division:'AFC East', teamName: ' New England Patriots', wins: 2, losses:5, ties:0},
    {​​division:'AFC East', teamName: ' New York Jets', wins: 0, losses:8, ties:0},
    {​​division:'AFC West', teamName: ' Kansas City Chiefs', wins: 7, losses:1, ties:0},
    {​​division:'AFC West', teamName: ' Las Vegas Raiders', wins: 4, losses:3, ties:0},
    {​​division:'AFC West', teamName: ' Denver Broncos', wins: 3, losses:4, ties:0},
    {​​division:'AFC West', teamName: ' Los Angeles Chargers', wins: 2, losses:5, ties:0},
    {​​division:'AFC North', teamName: 'Pittsburgh Steelers', wins: 7, losses: 0, ties: 0},​​
    {​​division:'AFC North', teamName: 'Baltimore Ravens', wins: 5, losses: 2, ties: 0}​​,
    {​​division:'AFC North', teamName: 'Cleveland Browns', wins: 5, losses: 3, ties: 0}​​,
    {​​division:'AFC North', teamName: 'Cincinnati Bengals', wins: 2, losses: 5, ties: 0}​,​
    {​​division:'AFC South', teamName: 'Tenessee Titans', wins: 5, losses: 2, ties: 0}​​,
    {​​division:'AFC South', teamName: 'Indianapolis Colts', wins: 5, losses: 2, ties: 0},​​
    {​​division:'AFC South', teamName: 'Houston Texans', wins: 1, losses: 6, ties: 0}​​,
    {​​division:'AFC South', teamName: 'Jacksonville Jaguars', wins: 1, losses: 6, ties: 0}​​
]

module.exports = afcConference;