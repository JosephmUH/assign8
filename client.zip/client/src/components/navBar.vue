<template>
    <div id="navbar" class="navBar">
        <div>
            <b-navbar type="dark" >
                <b-navbar-nav>
                    <b-nav-item><router-link to="/"> Home </router-link></b-nav-item>
                    <b-nav-item><router-link to="/afcEast"> AFC East </router-link></b-nav-item>
                    <b-nav-item><router-link to="/afcWest"> AFC West </router-link></b-nav-item>
                    <b-nav-item><router-link to="/afcNorth"> AFC North </router-link></b-nav-item>
                    <b-nav-item><router-link to="/afcSouth"> AFC South </router-link></b-nav-item>
                </b-navbar-nav>
            </b-navbar>
        </div>
    </div>
</template>

<script>
export default {
    
}
</script>

<style>
.navBar a{
    color: aqua;
}
</style>
