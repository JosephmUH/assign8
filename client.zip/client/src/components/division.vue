<template>
    <div id="division" class="division">
        <div id="result" class="result">
            <table id="teamTable" class="teamTable">
                <tr>
                    <th>Team Name</th>
                    <th>Wins</th>
                    <th>Losses</th>
                    <th>Ties</th>
                </tr>
                <tr v-for="(team, index) in divisionTeams" :key="index">
                    <td>{{team.teamName}}</td>
                    <td>{{team.wins}}</td>
                    <td>{{team.losses}}</td>
                    <td>{{team.ties}}</td>
                </tr>
            </table>
        </div>
    </div>
</template>


<script>
import axios from 'axios'
export default{
  name: 'home',
  data() {
    return {
      teams: []
    }
  },
 computed: {​​​​
        divisionTeams: function(){​​​​
            return this.teams.filter(team => {​​​​
                return team.division === this.$route.params.division;
            }​​​​)
        }​​​​
    }​​​​,
    created(){​​​​
        axios.get('http://localhost:8000/nflTeams').then(response => {​​​​
            this.teams = response.data;
            this.teams.sort((a,b) => {​​​​
                return (b.wins/b.losses) - (a.wins/a.losses);
                }​​​​)
            }​​​​).catch(error => {​​​​
                console.log(error);
        }​​​​)
    }​​​​
}​​​​

</script>